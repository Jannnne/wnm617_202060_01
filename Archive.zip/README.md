 # wnm617_202060_01

This is the class README, do not edit.


## Git process

- git status
- git add .
- git commit -m "[message]"
<<<<<<< HEAD
- optional (git commit -a -m "[message]"ta
=======
- optional (git commit -a -m "[message]")
>>>>>>> dceb508fe97771caa851b2650eb2420615aab08a
- git push origin master
- git pull origin master
- git pull [somerepository] master
