<?php


function PDOauth() {
	$host = "localhost";
	$user = "Jannnne";
	$pass = "HappyLife978";
	$dbname = "JW_products";
	return [
		"mysql:host=$host;dbname=$dbname;charset=utf8mb4",
      $user,
      $pass
	];
}